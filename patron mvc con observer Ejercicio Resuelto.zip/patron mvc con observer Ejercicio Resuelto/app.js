
const modeloSala = new ModeloSala()
const controladorSala = new ControladorSala(modeloSala)
const mailer = new Mailer( modeloSala )
const cerrarSala = new CerrarSala( modeloSala )

controladorSala.agregar({nombre: "juan", email: "juan@mail.com", edad:28})
controladorSala.agregar({nombre: "martina", email: "martina@mail.com", edad: 7})

window.addEventListener("load", () => {
    const vista = new Vista( controladorSala, modeloSala )
    vista.load()
})