class Vista {
    constructor( controlador, modelo ) {
        this.controlador = controlador
        this.modelo = modelo
        this.modelo.agregarSuscriptor( this.render )
    }
    load() {
        const data = this.controlador.obtenerTodos()
        this.render( data )

        document.addEventListener("submit", (evento) => {
            evento.preventDefault();
            var nombre = document.getElementById("nombre").value;
            var email = document.getElementById("email").value;
            var edad = parseInt(document.getElementById("edad").value);
            var persona = {nombre, email, edad};
            this.controlador.agregar(persona);
            evento.target.reset();

            })
    }
    
    render( asistentes ) {
        borrarTablas();
        asistentes.forEach(cargarRegistroTabla);
    }
}

function cargarRegistroTabla(persona) {

    if (persona.edad > 13 ) {
      var tabla = document.getElementById("tabla1").lastElementChild;
    } else {
      var tabla = document.getElementById("tabla2").lastElementChild;;
    }
    var fila = document.createElement("tr");

      var celda = document.createElement("td");
      celda.textContent = persona.nombre;
      fila.appendChild(celda);

      var celda = document.createElement("td");
      celda.textContent = persona.email;
      fila.appendChild(celda);
      
      var celda = document.createElement("td");
      celda.textContent = persona.edad;
      fila.appendChild(celda);
  
    tabla.appendChild(fila);
  
}

function borrarTablas() {
    document.getElementById("tabla1").lastElementChild.innerHTML = "";
    document.getElementById("tabla2").lastElementChild.innerHTML = "";
}