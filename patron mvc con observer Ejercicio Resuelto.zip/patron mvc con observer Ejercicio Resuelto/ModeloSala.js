class ModeloSala {
    constructor() {
        this.asistentes = []
        this.suscriptores = []
    }
    agregarAsistente( asistente ) {
        this.asistentes.push ( asistente )
        this.notificar()
    }
    devolverAsistentes() {
        return this.asistentes
    }
    devolverAsistente( nombre ) {
        return this.asistentes.filter(
            asistente => asistente.nombre == nombre
        )
    }
    agregarSuscriptor( callback ){
        this.suscriptores.push( callback )
    }
    notificar() {
        this.suscriptores.forEach( (suscriptor) => {
            suscriptor( this.asistentes )
        })
    }

}
