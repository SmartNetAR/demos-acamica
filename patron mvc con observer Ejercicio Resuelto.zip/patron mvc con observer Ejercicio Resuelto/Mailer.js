class Mailer {
    constructor( modelo ) {
        this.modelo = modelo
        this.modelo.agregarSuscriptor( this.enviarMail )
    }
    enviarMail( asistentes ) {
        console.log( "enviando mail a", asistentes[asistentes.length -1].email )
    }
}