class ControladorSala {
    constructor( modelo ) {
        this.sala = modelo
    }
    agregar( asistente ) {
        if ( asistente.edad )
        this.sala.agregarAsistente(asistente)
    }
    
    obtenerTodos() {
        return this.sala.devolverAsistentes()
    }

    obtenerUno( nombre ) {
        return this.sala.devolverAsistente( nombre )
    }

    borrar ( nombre ) {
        
    }
}