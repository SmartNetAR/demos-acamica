class CerrarSala {
    constructor( modelo ) {
        this.modelo = modelo
        this.modelo.agregarSuscriptor( this.cerrarSala )
    }
    cerrarSala( asistentes ) {
        if ( asistentes.length >= 5 ) {
            alert("Sala llena, cerrada....")
        }
    }
}